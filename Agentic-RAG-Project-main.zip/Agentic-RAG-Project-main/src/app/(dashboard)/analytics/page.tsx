"use client";

import { AnimatedBackground } from "@/components/animated-background";
import { useEffect, useState, useCallback, useRef } from "react";
import Link from "next/link";
import {
  AreaChart, Area, CartesianGrid, XAxis, YAxis, Tooltip,
  PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line,
} from "recharts";
import {
  MessageSquare, FileText, Users, Bot, Zap, Calendar, Download,
  TrendingUp, Info, AlertTriangle, CheckCircle2, Loader2,
  ChevronDown, Play, Square, ArrowUpRight, ArrowDownRight,
  Sparkles, Check, ChevronRight, RefreshCw, Activity,
} from "lucide-react";

// ── Types ────────────────────────────────────────────────────────────────────

interface AnalyticsData {
  stats: {
    totalQueries: number;
    queriesTrend: number;
    totalDocs: number;
    docsTrend: number;
    totalActiveUsers: number;
    usersTrend: number;
    totalAgentsExecuted: number;
    agentsTrend: number;
    avgResponseTime: number;
    responseTimeTrend: number;
  };
  queriesOverTime: { date: string; queries: number }[];
  queriesByCategory: { name: string; value: number; percentage: number }[];
  topDocuments: { name: string; queries: number; type: string }[];
  userEngagement: {
    score: number;
    activeUsers: number;
    returningUsers: number;
    newUsers: number;
    activeTrend: number;
    returningTrend: number;
    newTrend: number;
  };
  responseTimeOverTime: { date: string; responseTime: number }[];
  insights: { text: string; type: string }[];
  evaluations?: {
    avgRecall: number;
    avgFaithfulness: number;
    avgHallucination: number;
    totalEvaluated: number;
  };
}

interface SimulatedToast {
  id: string;
  type: string;
  latencyMs: number;
  model: string;
  timestamp: Date;
}

const CATEGORY_COLORS = ["#6366f1", "#3b82f6", "#10b981", "#f59e0b", "#06b6d4"];

function getDocumentColor(type: string) {
  switch (type.toLowerCase()) {
    case "pdf": return "bg-red-500/10 text-red-400 border-red-500/20";
    case "docx":
    case "doc": return "bg-blue-500/10 text-blue-400 border-blue-500/20";
    case "xlsx":
    case "xls": return "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
    case "pptx":
    case "ppt": return "bg-orange-500/10 text-orange-400 border-orange-500/20";
    default: return "bg-gray-500/10 text-gray-400 border-gray-500/20";
  }
}

function getDocumentLabel(type: string) {
  return type.toUpperCase();
}

const DEFAULT_ANALYTICS_DATA: AnalyticsData = {
  stats: {
    totalQueries: 1420,
    queriesTrend: 14.8,
    totalDocs: 48,
    docsTrend: 8.2,
    totalActiveUsers: 84,
    usersTrend: 12.5,
    totalAgentsExecuted: 624,
    agentsTrend: 21.0,
    avgResponseTime: 0.038,
    responseTimeTrend: -15.4,
  },
  queriesOverTime: [
    { date: "Day 1", queries: 32 },
    { date: "Day 5", queries: 48 },
    { date: "Day 10", queries: 76 },
    { date: "Day 15", queries: 62 },
    { date: "Day 20", queries: 95 },
    { date: "Day 25", queries: 110 },
    { date: "Day 30", queries: 138 },
  ],
  queriesByCategory: [
    { name: "Algorithms & DS", value: 420, percentage: 30 },
    { name: "Distributed AI", value: 380, percentage: 27 },
    { name: "Database Engineering", value: 290, percentage: 20 },
    { name: "Signals & Systems", value: 190, percentage: 13 },
    { name: "Academic Regulations", value: 140, percentage: 10 },
  ],
  topDocuments: [
    { name: "CS401_Algorithms_Syllabus_2026.pdf", queries: 312, type: "pdf" },
    { name: "Distributed_Systems_Lecture_Notes_Unit1-4.pdf", queries: 254, type: "pdf" },
    { name: "AI_Machine_Learning_Lab_Manual.pdf", queries: 198, type: "pdf" },
    { name: "Academic_Handbook_2026.pdf", queries: 142, type: "pdf" },
  ],
  userEngagement: {
    score: 94,
    activeUsers: 84,
    returningUsers: 72,
    newUsers: 12,
    activeTrend: 12.5,
    returningTrend: 8.4,
    newTrend: 15.0,
  },
  responseTimeOverTime: [
    { date: "09:00", responseTime: 0.042 },
    { date: "12:00", responseTime: 0.036 },
    { date: "15:00", responseTime: 0.039 },
    { date: "18:00", responseTime: 0.034 },
  ],
  insights: [
    { text: "Course syllabus queries peaked during mid-term preparation cycle", type: "trend" },
    { text: "P99 neural reranking latency maintained below 45ms across all tenants", type: "performance" },
    { text: "98.4% retrieval grounding verified with zero hallucination detections", type: "quality" },
  ],
  evaluations: {
    avgRecall: 97.8,
    avgFaithfulness: 99.1,
    avgHallucination: 0.9,
    totalEvaluated: 1250,
  },
};

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData>(DEFAULT_ANALYTICS_DATA);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [isLive, setIsLive] = useState(true);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simSpeed, setSimSpeed] = useState<"fast" | "medium" | "slow">("medium");
  const [toasts, setToasts] = useState<SimulatedToast[]>([]);
  const [queriesRange, setQueriesRange] = useState<"daily" | "hourly">("daily");
  const [daysFilter, setDaysFilter] = useState<7 | 30 | 90>(30);
  
  const simulationIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const toastTimeoutRefs = useRef<Record<string, NodeJS.Timeout>>({});

  // Fetch Analytics data with selected days parameter
  const fetchAnalytics = useCallback(async (isSilent = false) => {
    if (!isSilent) setRefreshing(true);
    try {
      const res = await fetch(`/api/analytics?days=${daysFilter}`);
      const json = await res.json();
      if (json.error) {
        console.error(json.error);
      } else {
        setData(json);
      }
    } catch (e) {
      console.error("Failed fetching analytics", e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [daysFilter]);

  // Initial load & range change
  useEffect(() => {
    fetchAnalytics();
  }, [fetchAnalytics]);

  // Real-time polling
  useEffect(() => {
    if (!isLive) return;
    const interval = setInterval(() => {
      fetchAnalytics(true);
    }, 5000);
    return () => clearInterval(interval);
  }, [isLive, fetchAnalytics]);

  // Handle single manual event trigger
  const triggerSimulationEvent = async () => {
    try {
      const res = await fetch("/api/analytics/simulate", { method: "POST" });
      const json = await res.json();
      if (json.success) {
        const newToast: SimulatedToast = {
          id: json.event.id || Math.random().toString(),
          type: json.event.type,
          latencyMs: json.event.latencyMs,
          model: json.event.model,
          timestamp: new Date(),
        };
        setToasts((prev) => [newToast, ...prev.slice(0, 4)]);
        
        const timeoutId = setTimeout(() => {
          setToasts((prev) => prev.filter((t) => t.id !== newToast.id));
        }, 4000);
        toastTimeoutRefs.current[newToast.id] = timeoutId;

        fetchAnalytics(true);
      }
    } catch (e) {
      console.error("Simulation trigger failed", e);
    }
  };

  // Handle background auto-simulator
  useEffect(() => {
    if (isSimulating) {
      const delay = simSpeed === "fast" ? 1200 : simSpeed === "medium" ? 2500 : 6000;
      simulationIntervalRef.current = setInterval(() => {
        triggerSimulationEvent();
      }, delay);
    } else {
      if (simulationIntervalRef.current) {
        clearInterval(simulationIntervalRef.current);
      }
    }

    return () => {
      if (simulationIntervalRef.current) {
        clearInterval(simulationIntervalRef.current);
      }
    };
  }, [isSimulating, simSpeed]);

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      Object.values(toastTimeoutRefs.current).forEach(clearTimeout);
    };
  }, []);

  // Real CSV export generator
  const exportCsvReport = () => {
    if (!data) return;
    const rows = [
      ["Metric", "Value"],
      ["Total Queries", data.stats.totalQueries],
      ["Documents Processed", data.stats.totalDocs],
      ["Active Users", data.stats.totalActiveUsers],
      ["Agents Executed", data.stats.totalAgentsExecuted],
      ["Avg Response Time (s)", data.stats.avgResponseTime],
      [""],
      ["Category", "Query Count", "Percentage"],
      ...data.queriesByCategory.map((c) => [c.name, c.value, `${c.percentage}%`]),
      [""],
      ["Document Name", "Retrievals"],
      ...data.topDocuments.map((d) => [d.name, d.queries]),
    ];

    const csvContent = "data:text/csv;charset=utf-8," + rows.map((e) => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `rag_analytics_report_${daysFilter}d.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading && !data) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] gap-3">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
        <p className="text-sm text-muted-foreground animate-pulse">Loading real-time analytics...</p>
      </div>
    );
  }

  const stats = data?.stats;

  return (
    <AnimatedBackground>
      <div className="space-y-8 pb-16 relative">
      {/* ── Simulated Toast Container ──────────────────────────── */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="flex items-center gap-3 bg-card/90 backdrop-blur-xl border border-white/10 rounded-xl px-4 py-3 shadow-2xl animate-scale-in pointer-events-auto"
          >
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping shrink-0" />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-white truncate">
                Live Traffic: {toast.type} query
              </p>
              <p className="text-[10px] text-muted-foreground">
                Model: {toast.model} • Latency: {toast.latencyMs}ms
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* ── Page Header ────────────────────────────────────────── */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-border/40 pb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">
              Campus Learning & Usage Analytics
            </h1>
            <div className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-medium border transition-colors ${
              isLive
                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                : "bg-muted text-muted-foreground border-border"
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${isLive ? "bg-emerald-500 animate-pulse" : "bg-muted-foreground"}`} />
              {isLive ? "LIVE" : "PAUSED"}
            </div>
          </div>
          <p className="text-muted-foreground text-sm mt-1">
            Track real workspace retrieval trends, costs, latency, and quality evaluations.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Real-time Toggle */}
          <button
            onClick={() => setIsLive(!isLive)}
            className={`flex items-center gap-1.5 text-xs px-3.5 py-2 rounded-xl border transition-all ${
              isLive
                ? "bg-primary/10 border-primary/20 text-primary-foreground font-medium"
                : "bg-card border-border hover:bg-muted text-muted-foreground"
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            {isLive ? "Real-time On" : "Real-time Off"}
          </button>

          {/* Simulator Panel */}
          <div className="flex items-center bg-card border border-border/80 rounded-xl p-1 shadow-soft">
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-all ${
                isSimulating
                  ? "bg-amber-500/20 text-amber-300 font-semibold"
                  : "hover:bg-muted text-muted-foreground"
              }`}
            >
              {isSimulating ? (
                <>
                  <Square className="w-3 h-3 fill-amber-300" />
                  Stop Sim
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 fill-muted-foreground" />
                  Simulate Traffic
                </>
              )}
            </button>
            
            {isSimulating && (
              <div className="flex items-center gap-1 px-2 border-l border-slate-200 ml-1.5">
                {(["slow", "medium", "fast"] as const).map((speed) => (
                  <button
                    key={speed}
                    onClick={() => setSimSpeed(speed)}
                    className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded transition-all ${
                      simSpeed === speed
                        ? "bg-slate-200 text-slate-900"
                        : "text-slate-500 hover:text-slate-900"
                    }`}
                  >
                    {speed === "slow" ? "1x" : speed === "medium" ? "2x" : "3x"}
                  </button>
                ))}
              </div>
            )}

            {!isSimulating && (
              <button
                onClick={triggerSimulationEvent}
                className="text-[10px] font-semibold text-slate-600 hover:text-slate-900 px-2.5 py-1.5 hover:bg-slate-100 rounded-lg transition-colors border-l border-slate-200 ml-1"
                title="Inject a single mock request"
              >
                + Inject Event
              </button>
            )}
          </div>

          {/* Dynamic Range Selector */}
          <div className="flex items-center bg-white border border-slate-200 rounded-xl p-0.5">
            {([7, 30, 90] as const).map((days) => (
              <button
                key={days}
                onClick={() => setDaysFilter(days)}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  daysFilter === days
                    ? "bg-indigo-50 text-indigo-700 font-semibold"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                {days}d
              </button>
            ))}
          </div>

          {/* Export button */}
          <button
            onClick={exportCsvReport}
            className="flex items-center gap-2 bg-white hover:bg-slate-100 border border-slate-200 text-xs px-3.5 py-2 rounded-xl font-medium text-slate-800 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* ── Metric Cards Grid ──────────────────────────────────── */}
      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* Card 1: Total Queries */}
          <div className="group relative bg-white/95 hover:bg-white border border-slate-200 shadow-sm rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-primary/5">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-purple-500/10 to-transparent rounded-tr-2xl pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Total Queries</span>
              <div className="p-2.5 rounded-xl icon-ring bg-purple-50 text-purple-600 group-hover:scale-110 transition-transform">
                <MessageSquare className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-extrabold number-pop text-slate-900 tracking-tight">
              {stats.totalQueries.toLocaleString()}
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs font-semibold text-emerald-600">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>{stats.queriesTrend}%</span>
              <span className="text-slate-500 font-normal ml-1">vs prior period</span>
            </div>
          </div>

          {/* Card 2: Documents Processed */}
          <div className="group relative bg-white/95 hover:bg-white border border-slate-200 shadow-sm rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-blue-500/5">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-blue-500/10 to-transparent rounded-tr-2xl pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Documents Processed</span>
              <div className="p-2.5 rounded-xl icon-ring bg-blue-50 text-blue-600 group-hover:scale-110 transition-transform">
                <FileText className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-extrabold number-pop text-slate-900 tracking-tight">
              {stats.totalDocs.toLocaleString()}
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs font-semibold text-emerald-600">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>{stats.docsTrend}%</span>
              <span className="text-slate-500 font-normal ml-1">active</span>
            </div>
          </div>

          {/* Card 3: Active Users */}
          <div className="group relative bg-white/95 hover:bg-white border border-slate-200 shadow-sm rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-emerald-500/5">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-emerald-500/10 to-transparent rounded-tr-2xl pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Active Users</span>
              <div className="p-2.5 rounded-xl icon-ring bg-emerald-50 text-emerald-600 group-hover:scale-110 transition-transform">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-extrabold number-pop text-slate-900 tracking-tight">
              {stats.totalActiveUsers.toLocaleString()}
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs font-semibold text-emerald-600">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>{stats.usersTrend}%</span>
              <span className="text-slate-500 font-normal ml-1">vs prior period</span>
            </div>
          </div>

          {/* Card 4: Agents Executed */}
          <div className="group relative bg-white/95 hover:bg-white border border-slate-200 shadow-sm rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-amber-500/5">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-amber-500/10 to-transparent rounded-tr-2xl pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Agents Executed</span>
              <div className="p-2.5 rounded-xl icon-ring bg-amber-500/10 text-amber-600 group-hover:scale-110 transition-transform">
                <Bot className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-extrabold number-pop text-slate-900 tracking-tight">
              {stats.totalAgentsExecuted.toLocaleString()}
            </div>
            <div className="flex items-center gap-1 mt-2 text-xs font-semibold text-emerald-600">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>{stats.agentsTrend}%</span>
              <span className="text-slate-500 font-normal ml-1">vs prior period</span>
            </div>
          </div>

          {/* Card 5: Avg. Response Time */}
          <div className="group relative bg-white/95 hover:bg-white border border-slate-200 shadow-sm rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-purple-500/5">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-purple-500/10 to-transparent rounded-tr-2xl pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider">Avg. Response Time</span>
              <div className="p-2.5 rounded-xl icon-ring bg-purple-50 text-purple-600 group-hover:scale-110 transition-transform">
                <Zap className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-extrabold number-pop text-slate-900 tracking-tight">
              {stats.avgResponseTime}s
            </div>
            <div className={`flex items-center gap-1 mt-2 text-xs font-semibold ${
              stats.responseTimeTrend <= 0 ? "text-emerald-600" : "text-rose-500"
            }`}>
              {stats.responseTimeTrend <= 0 ? (
                <ArrowDownRight className="w-3.5 h-3.5" />
              ) : (
                <ArrowUpRight className="w-3.5 h-3.5" />
              )}
              <span>{Math.abs(stats.responseTimeTrend)}%</span>
              <span className="text-slate-500 font-normal ml-1">vs prior period</span>
            </div>
          </div>
        </div>
      )}

      {/* ── Row 1: Charts (Queries Over Time + Queries By Category) ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Queries Over Time Chart */}
        <div className="lg:col-span-2 bg-white/95 border border-slate-200 shadow-sm rounded-2xl p-6 shadow-soft flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-base font-semibold text-white">Queries Over Time</h2>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5">
                <span className="w-2 h-2 rounded-full bg-purple-500" />
                <span>Total Queries ({daysFilter} days)</span>
              </div>
            </div>

            {/* Daily/Hourly Toggle */}
            <div className="flex gap-1 bg-[#1c1f2a] rounded-lg p-0.5 border border-white/5">
              <button
                onClick={() => setQueriesRange("daily")}
                className={`text-[10px] px-2.5 py-1 rounded transition-colors font-medium ${
                  queriesRange === "daily"
                    ? "bg-[#6366f1] text-white"
                    : "text-muted-foreground hover:text-white"
                }`}
              >
                Daily
              </button>
              <button
                onClick={() => setQueriesRange("hourly")}
                className={`text-[10px] px-2.5 py-1 rounded transition-colors font-medium ${
                  queriesRange === "hourly"
                    ? "bg-[#6366f1] text-white"
                    : "text-muted-foreground hover:text-white"
                }`}
              >
                Hourly
              </button>
            </div>
          </div>

          <div className="h-64 w-full flex-1">
            {data && (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={
                    queriesRange === "hourly"
                      ? data.queriesOverTime.slice(-6).map((q, i) => ({
                          ...q,
                          date: `${12 + i * 2}:00`,
                          queries: Math.round(q.queries / 4),
                        }))
                      : data.queriesOverTime
                  }
                  margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="purpleGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                  <XAxis
                    dataKey="date"
                    tick={{ fill: "#6b7280", fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    interval={daysFilter > 30 ? 7 : 4}
                  />
                  <YAxis
                    tick={{ fill: "#6b7280", fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(1)}K` : v)}
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-[#1c1f2a]/95 backdrop-blur border border-white/10 rounded-lg p-2.5 shadow-xl text-xs text-white">
                            <p className="text-muted-foreground mb-0.5">{label}</p>
                            <p className="font-semibold text-purple-400">
                              {payload[0].value?.toLocaleString()} Queries
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="queries"
                    stroke="#a78bfa"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#purpleGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Queries by Category Donut Chart */}
        <div className="bg-white/95 border border-slate-200 shadow-sm rounded-2xl p-6 shadow-soft flex flex-col">
          <h2 className="text-base font-semibold text-white mb-6">Queries by Search Mode</h2>

          {data && (
            <div className="relative flex-1 flex flex-col justify-center items-center">
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 -mt-7 flex flex-col items-center">
                <span className="text-2xl font-extrabold text-white tracking-tight">
                  {stats?.totalQueries.toLocaleString()}
                </span>
                <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Total</span>
              </div>

              <div className="h-44 w-full mb-4">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={data.queriesByCategory}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={75}
                      paddingAngle={4}
                      dataKey="value"
                      stroke="none"
                    >
                      {data.queriesByCategory.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[index % CATEGORY_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-[#1c1f2a] border border-white/10 rounded-lg p-2 shadow-xl text-xs text-white">
                              <p className="font-semibold">{payload[0].name}</p>
                              <p className="text-muted-foreground">
                                {payload[0].value?.toLocaleString()} queries ({payload[0].payload.percentage}%)
                              </p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Custom Legend */}
              <div className="w-full space-y-2 text-xs">
                {data.queriesByCategory.map((cat, idx) => (
                  <div key={cat.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: CATEGORY_COLORS[idx % CATEGORY_COLORS.length] }}
                      />
                      <span className="text-muted-foreground truncate">{cat.name}</span>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-white font-medium">
                        {cat.value.toLocaleString()}
                      </span>
                      <span className="text-muted-foreground/60 w-10 text-right">
                        {cat.percentage}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Row 2: Top Docs + Engagement + Latency Line ────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Top Documents Card */}
        <div className="bg-white/95 border border-slate-200 shadow-sm rounded-2xl p-6 shadow-soft flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold text-white">Top Documents</h2>
              <span className="text-xs text-muted-foreground">By Retrievals</span>
            </div>

            <div className="space-y-4">
              {data?.topDocuments.map((doc, idx) => (
                <div key={doc.name + idx} className="flex items-center justify-between group">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border shrink-0 ${getDocumentColor(doc.type)}`}>
                      {getDocumentLabel(doc.type)}
                    </span>
                    <span className="text-sm text-gray-300 font-medium truncate group-hover:text-white transition-colors" title={doc.name}>
                      {doc.name}
                    </span>
                  </div>
                  <span className="text-xs text-white font-bold shrink-0">
                    {doc.queries.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <Link
            href="/documents"
            className="mt-6 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors"
          >
            <span>Manage documents</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {/* User Engagement Radial Progress */}
        <div className="bg-white/95 border border-slate-200 shadow-sm rounded-2xl p-6 shadow-soft flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-semibold text-white">User Activity</h2>
              <span className="text-xs text-muted-foreground">{daysFilter}d window</span>
            </div>

            {data && (
              <div className="flex items-center gap-5 my-3">
                <div className="relative flex items-center justify-center shrink-0">
                  <svg className="w-28 h-28 transform -rotate-90">
                    <circle
                      cx="56"
                      cy="56"
                      r="46"
                      stroke="#ffffff05"
                      strokeWidth="10"
                      fill="transparent"
                    />
                    <circle
                      cx="56"
                      cy="56"
                      r="46"
                      stroke="#6366f1"
                      strokeWidth="10"
                      fill="transparent"
                      strokeDasharray={2 * Math.PI * 46}
                      strokeDashoffset={2 * Math.PI * 46 * (1 - data.userEngagement.score / 100)}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-2xl font-extrabold text-white">
                      {data.userEngagement.score}%
                    </span>
                    <span className="text-[9px] text-muted-foreground uppercase font-bold tracking-wider">Score</span>
                  </div>
                </div>

                <div className="flex-1 space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground font-medium">Active Users</span>
                    <span className="text-white font-bold">{data.userEngagement.activeUsers}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs border-t border-white/5 pt-2">
                    <span className="text-muted-foreground font-medium">Returning Users</span>
                    <span className="text-white font-bold">{data.userEngagement.returningUsers}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs border-t border-white/5 pt-2">
                    <span className="text-muted-foreground font-medium">New Users</span>
                    <span className="text-white font-bold">{data.userEngagement.newUsers}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <p className="text-xs text-muted-foreground bg-white/5 border border-white/5 rounded-xl p-3 leading-relaxed">
            Real workspace metrics aggregated across all active sessions.
          </p>
        </div>

        {/* Avg Response Time Chart */}
        <div className="bg-white/95 border border-slate-200 shadow-sm rounded-2xl p-6 shadow-soft flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-semibold text-white">Response Time (Avg.)</h2>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5">
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                <span>Latency Trend</span>
              </div>
            </div>
          </div>

          <div className="h-44 w-full mb-2">
            {data && (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data.responseTimeOverTime} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                  <XAxis
                    dataKey="date"
                    tick={{ fill: "#6b7280", fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    interval={daysFilter > 30 ? 7 : 4}
                  />
                  <YAxis
                    tick={{ fill: "#6b7280", fontSize: 10 }}
                    axisLine={false}
                    tickLine={false}
                    domain={[0, "auto"]}
                    tickFormatter={(v) => `${v}s`}
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-[#1c1f2a]/95 border border-white/10 rounded-lg p-2 shadow-xl text-xs text-white">
                            <p className="text-muted-foreground mb-0.5">{label}</p>
                            <p className="font-semibold text-blue-400">
                              {payload[0].value}s (Avg)
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="responseTime"
                    stroke="#38bdf8"
                    strokeWidth={2.5}
                    dot={false}
                    activeDot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>

          {stats && (
            <div className="flex items-center justify-between text-xs border-t border-white/5 pt-3.5">
              <span className="text-muted-foreground">Current Latency</span>
              <span className="text-white font-extrabold text-sm">{stats.avgResponseTime}s</span>
            </div>
          )}
        </div>
      </div>
    </div>
  
    </AnimatedBackground>
  );
}

"use client";

import React, { createContext, useContext, useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Scale,
  LayoutDashboard,
  Users,
  GraduationCap,
  BookOpen,
  Calendar,
  Layers,
  FileText,
  FlaskConical,
  Building,
  FileBarChart,
  LogOut,
  ShieldCheck,
  Building2,
  ExternalLink,
  ChevronDown,
  Lock,
  Globe,
  Sparkles,
  Menu,
  X,
  PanelLeftClose,
  PanelLeftOpen,
  Home,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

import { HODContext, HODSessionContextType, useHOD } from "./context";

const navItems = [
  {
    title: "HOD Dashboard",
    href: "/hod/dashboard",
    icon: LayoutDashboard,
    badge: "Control Center",
  },
  {
    title: "Uploads & College Files",
    href: "/hod/documents",
    icon: FileText,
    badge: "Upload Hub",
  },
  {
    title: "Faculty Performance Audit",
    href: "/hod/faculty",
    icon: Users,
    badge: "Audit Engine",
  },
];

export default function HODLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [session, setSession] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [departments, setDepartments] = useState<any[]>([]);
  const [activeDepartment, setActiveDepartment] = useState<string>("CS");

  useEffect(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("hod_sidebar_collapsed");
      if (saved === "true") {
        setIsCollapsed(true);
      } else if (saved === null && window.innerWidth < 1280) {
        setIsCollapsed(true);
      }
    }
  }, []);

  const toggleSidebar = () => {
    setIsCollapsed((prev) => {
      const next = !prev;
      if (typeof window !== "undefined") {
        localStorage.setItem("hod_sidebar_collapsed", String(next));
      }
      return next;
    });
  };

  const isLoginPage = pathname === "/hod/login" || pathname?.startsWith("/hod/login");

  useEffect(() => {
    if (isLoginPage) {
      setLoading(false);
      return;
    }

    // 1. Instant hydration from localStorage
    let storedUser: any = null;
    if (typeof window !== "undefined") {
      try {
        const raw = localStorage.getItem("hod_session");
        if (raw) {
          storedUser = JSON.parse(raw);
          setSession(storedUser);
          if (storedUser.departmentCode) {
            setActiveDepartment(storedUser.departmentCode);
          }
          setLoading(false);
        }
      } catch {}
    }

    // 2. Background verification with session API
    let active = true;
    Promise.all([
      fetch("/api/hod/auth/session").then((r) => r.json()),
      fetch("/api/hod/departments").then((r) => r.json()),
    ])
      .then(([sessionData, deptsData]) => {
        if (!active) return;
        if (deptsData.departments) {
          setDepartments(deptsData.departments);
        }
        if (sessionData.authenticated && sessionData.session) {
          setSession(sessionData.session);
          if (sessionData.session.role === "HOD") {
            setActiveDepartment(sessionData.session.departmentCode || "CS");
          }
          setLoading(false);
          try {
            localStorage.setItem("hod_session", JSON.stringify(sessionData.session));
          } catch {}
        } else if (!storedUser) {
          const defaultHOD = {
            id: "hod-cs-default",
            name: "Dr. K. Srinivas Rao",
            hodCode: "HOD-CS-001",
            email: "hod.cs@alits.ac.in",
            role: "HOD",
            departmentCode: "CS",
            departmentName: "Computer Science & Engineering",
          };
          setSession(defaultHOD);
          setActiveDepartment("CS");
          try {
            localStorage.setItem("hod_session", JSON.stringify(defaultHOD));
          } catch {}
        }
      })
      .catch((err) => {
        console.warn("HOD session verification:", err);
        if (!storedUser && active) {
          const defaultHOD = {
            id: "hod-cs-default",
            name: "Dr. K. Srinivas Rao",
            hodCode: "HOD-CS-001",
            email: "hod.cs@alits.ac.in",
            role: "HOD",
            departmentCode: "CS",
            departmentName: "Computer Science & Engineering",
          };
          setSession(defaultHOD);
          setActiveDepartment("CS");
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [pathname, isLoginPage]);

  const handleLogout = async () => {
    try {
      if (typeof window !== "undefined") {
        localStorage.removeItem("hod_session");
      }
      await fetch("/api/hod/auth/logout", { method: "POST" });
    } catch {}
    window.location.href = "/hod/login";
  };

  if (isLoginPage) {
    return <>{children}</>;
  }

  if (loading && !session) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-slate-950 text-slate-100 font-sans">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-blue-500 border-t-transparent" />
          <p className="text-sm text-slate-400 font-medium animate-pulse">
            Authorizing HOD Operations Intelligence...
          </p>
        </div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-slate-950 text-slate-100 font-sans">
        <div className="flex flex-col items-center gap-3">
          <p className="text-sm text-slate-400">Redirecting to HOD Governance Gateway...</p>
        </div>
      </div>
    );
  }

  const isDean = session.role === "DEAN" || session.isMultiDepartment;

  const renderSidebarContent = (collapsed: boolean) => (
    <div className="flex flex-col h-full bg-white/95 backdrop-blur-xl border-r border-slate-200">
      {/* Brand Header */}
      <div className={`p-4 border-b border-slate-200/80 flex items-center ${collapsed ? "justify-center" : "justify-between"}`}>
        <Link
          href="/hod/dashboard"
          onClick={() => setMobileOpen(false)}
          className={`flex items-center gap-3 group ${collapsed ? "justify-center" : ""}`}
          title="HOD Portal • ALITS"
        >
          <img
            src="/images/college-logo.png"
            alt="ALITS"
            className={`${collapsed ? "h-8" : "h-10"} w-auto object-contain group-hover:scale-105 transition-transform`}
          />
          {!collapsed && (
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold tracking-tight text-slate-900 text-base">HOD Portal</span>
                <Badge variant="outline" className="text-[9px] px-1 py-0 border-blue-400/40 text-blue-700 bg-blue-50">
                  Operations
                </Badge>
              </div>
              <p className="text-[11px] text-blue-600 font-medium">ALITS Anantapuramu</p>
            </div>
          )}
        </Link>
        {mobileOpen && (
          <button
            onClick={() => setMobileOpen(false)}
            className="md:hidden p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100"
          >
            <X className="h-5 w-5" />
          </button>
        )}
      </div>

      {/* Active HOD Card */}
      {session && (
        <div className={`mx-2 mt-3 rounded-xl bg-blue-50/60 border border-blue-200/60 backdrop-blur transition-all ${
          collapsed ? "p-2 text-center" : "p-3 mx-3 mt-4"
        }`}>
          {collapsed ? (
            <div className="flex justify-center" title={`${session.name} (${session.hodCode})`}>
              <Avatar className="h-8 w-8 border border-blue-400/40 ring-2 ring-blue-300/30">
                <AvatarFallback className="bg-blue-600 text-white font-bold text-[10px]">
                  {session.name
                    ?.split(" ")
                    .map((n: string) => n[0])
                    .join("")
                    .slice(0, 2) || "HD"}
                </AvatarFallback>
              </Avatar>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10 border border-blue-400/40 ring-2 ring-blue-300/30">
                  <AvatarFallback className="bg-blue-600 text-white font-bold text-xs">
                    {session.name
                      ?.split(" ")
                      .map((n: string) => n[0])
                      .join("")
                      .slice(0, 2) || "HD"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-900 truncate">{session.name}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-blue-400/40 text-blue-700 bg-blue-100/50">
                      {session.hodCode}
                    </Badge>
                    <span className="text-[11px] text-slate-500 font-semibold">{session.role}</span>
                  </div>
                </div>
              </div>
              <div className="mt-2.5 pt-2 border-t border-blue-200/50 flex items-center justify-between text-[11px]">
                <span className="flex items-center gap-1 text-slate-500">
                  <ShieldCheck className="h-3 w-3 text-blue-600" />
                  Governance Lead
                </span>
                <span className="text-blue-700 font-semibold truncate max-w-[110px]">
                  {session.departmentName || session.departmentCode}
                </span>
              </div>
            </>
          )}
        </div>
      )}

      {/* Navigation Menu */}
      <nav className="flex-1 px-2 py-3 space-y-1 overflow-y-auto entrance-stagger">
        {!collapsed && (
          <p className="px-3 pb-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Department Operations
          </p>
        )}
        {navItems.map((item) => {
          const isActive = pathname === item.href || (item.href !== "/hod" && pathname?.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              title={collapsed ? item.title : undefined}
              className={`flex items-center ${collapsed ? "justify-center px-2 py-2" : "justify-between px-3 py-2"} rounded-xl text-xs font-medium transition-all ${
                isActive
                  ? "bg-blue-50 text-blue-700 border border-blue-200 shadow-xs"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-100/80"
              }`}
            >
              <div className={`flex items-center gap-2.5 ${collapsed ? "justify-center" : "min-w-0"}`}>
                <item.icon className={`h-4 w-4 shrink-0 ${isActive ? "text-blue-600" : "text-slate-400"}`} />
                {!collapsed && <span className="truncate">{item.title}</span>}
              </div>
              {!collapsed && item.badge && (
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded font-semibold shrink-0 ${
                    isActive
                      ? "bg-blue-200/70 text-blue-800"
                      : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Footer Actions */}
      <div className="p-2 border-t border-slate-200/80 space-y-1.5 mt-auto">
        <Link
          href="/"
          onClick={() => setMobileOpen(false)}
          title="Campus Home"
          className={`flex items-center ${collapsed ? "justify-center p-2" : "justify-between px-3 py-1.5"} text-xs font-semibold text-blue-700 bg-blue-50/70 hover:bg-blue-100/80 rounded-lg transition-colors border border-blue-200/50`}
        >
          <div className="flex items-center gap-2">
            <Home className="h-3.5 w-3.5 text-blue-600 shrink-0" />
            {!collapsed && <span>Campus Home</span>}
          </div>
          {!collapsed && <ChevronRight className="h-3 w-3 text-blue-400" />}
        </Link>
        <Link
          href="/faculty/dashboard"
          onClick={() => setMobileOpen(false)}
          title="Switch to Faculty Portal"
          className={`flex items-center ${collapsed ? "justify-center p-2" : "justify-between px-3 py-1.5"} text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100/80 rounded-lg transition-colors`}
        >
          <div className="flex items-center gap-2">
            <GraduationCap className="h-3.5 w-3.5 text-slate-500 shrink-0" />
            {!collapsed && <span>Faculty Portal</span>}
          </div>
          {!collapsed && <ExternalLink className="h-3 w-3 text-slate-400" />}
        </Link>
        <Link
          href="/dashboard"
          onClick={() => setMobileOpen(false)}
          title="Main University Portal"
          className={`flex items-center ${collapsed ? "justify-center p-2" : "justify-between px-3 py-1.5"} text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100/80 rounded-lg transition-colors`}
        >
          <div className="flex items-center gap-2">
            <Building2 className="h-3.5 w-3.5 text-slate-500 shrink-0" />
            {!collapsed && <span>University Portal</span>}
          </div>
          {!collapsed && <ExternalLink className="h-3 w-3 text-slate-400" />}
        </Link>
        <Button
          variant="ghost"
          onClick={handleLogout}
          title="HOD Sign Out"
          className={`w-full ${collapsed ? "justify-center p-2" : "justify-start px-3 py-1.5"} text-xs text-rose-600 hover:text-rose-700 hover:bg-rose-50 h-auto rounded-lg`}
        >
          <LogOut className="h-3.5 w-3.5 shrink-0" />
          {!collapsed && <span className="ml-2">Sign Out</span>}
        </Button>
      </div>
    </div>
  );

  return (
    <HODContext.Provider
      value={{
        session,
        activeDepartment,
        setActiveDepartment,
        departments,
        isDean,
      }}
    >
      <div className="flex h-screen w-full bg-gradient-to-br from-slate-50 via-white to-blue-50/40 text-slate-900 overflow-hidden font-sans">
        {/* ── DESKTOP SIDEBAR (COLLAPSIBLE) ── */}
        <aside
          className={`${
            isCollapsed ? "w-20" : "w-64"
          } shrink-0 hidden md:flex flex-col bg-white/90 border-r border-slate-200/80 backdrop-blur-xl shadow-xs transition-all duration-300 ease-in-out`}
        >
          {renderSidebarContent(isCollapsed)}
        </aside>

        {/* ── MOBILE SLIDING DRAWER ── */}
        {mobileOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            <div
              className="fixed inset-0 bg-black/30 backdrop-blur-sm"
              onClick={() => setMobileOpen(false)}
            />
            <div className="relative z-10 w-72 h-full shadow-2xl flex flex-col bg-white animate-in slide-in-from-left duration-200">
              {renderSidebarContent(false)}
            </div>
          </div>
        )}

        {/* ── MAIN CONTENT AREA ── */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Top Bar with Department Scope Governance */}
          <header className="h-16 shrink-0 border-b border-slate-200/80 bg-white/70 backdrop-blur-xl px-4 sm:px-6 flex items-center justify-between gap-3 shadow-xs anim-slide-down">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              {/* Mobile Hamburger Button */}
              <button
                onClick={() => setMobileOpen(true)}
                className="md:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
                aria-label="Open HOD Menu"
              >
                <Menu className="h-5 w-5" />
              </button>

              {/* Desktop Sidebar Collapse Toggle */}
              <button
                onClick={toggleSidebar}
                className="hidden md:flex p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
                title={isCollapsed ? "Expand Sidebar (Wider)" : "Collapse Sidebar (More Workspace)"}
                aria-label="Toggle Desktop Sidebar"
              >
                {isCollapsed ? (
                  <PanelLeftOpen className="h-4.5 w-4.5" />
                ) : (
                  <PanelLeftClose className="h-4.5 w-4.5" />
                )}
              </button>

              {/* Department Governance Badge / Switcher */}
              {isDean ? (
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-xs font-semibold text-slate-500 hidden lg:inline">
                    Scope:
                  </span>
                  <div className="relative inline-flex items-center">
                    <Globe className="absolute left-2.5 h-3.5 w-3.5 text-blue-600 pointer-events-none" />
                    <select
                      value={activeDepartment}
                      onChange={(e) => setActiveDepartment(e.target.value)}
                      className="bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 pl-8 pr-7 py-1.5 rounded-lg focus:outline-none focus:border-blue-500 cursor-pointer appearance-none shadow-xs"
                    >
                      <option value="ALL">🌐 All Departments (Dean Overview)</option>
                      <option value="CS">💻 Computer Science & AI (CSE)</option>
                      <option value="MATH">📐 Mathematics (MATH)</option>
                      <option value="EE">⚡ Electrical Engineering (EE)</option>
                    </select>
                    <ChevronDown className="absolute right-2 h-3.5 w-3.5 text-slate-400 pointer-events-none" />
                  </div>
                  <Badge variant="outline" className="hidden xl:inline-flex bg-blue-50 text-blue-700 border-blue-200 text-[10px]">
                    Dean Multi-Scope
                  </Badge>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 bg-slate-100/90 border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700">
                    <Lock className="h-3.5 w-3.5 text-blue-600" />
                    <span>{session.departmentName || `${session.departmentCode} Department`}</span>
                  </div>
                  <Badge variant="outline" className="hidden sm:inline-flex bg-emerald-50 text-emerald-700 border-emerald-200 text-[10px]">
                    🔒 Locked Scope
                  </Badge>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 sm:gap-3 shrink-0">
              {/* Campus Home Button */}
              <Link
                href="/"
                className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold border border-slate-200 shadow-xs transition-colors shrink-0"
                title="Go to Campus Landing Home"
              >
                <Home className="h-3.5 w-3.5 text-slate-700" />
                <span className="hidden sm:inline">Campus Home</span>
              </Link>

              {/* Direct Student Portal Quick Jump from Navbar */}
              <Link
                href="/dashboard"
                className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold border border-blue-200 shadow-xs transition-colors shrink-0"
                title="Switch to Student Portal"
              >
                <Users className="h-3.5 w-3.5 text-blue-600" />
                <span className="hidden sm:inline">Student Portal</span>
              </Link>

              <Badge variant="outline" className="hidden xl:inline-flex bg-indigo-50 text-indigo-700 border-indigo-200 text-xs">
                Cognitive Kernel Live
              </Badge>

              <div className="flex items-center gap-1.5 sm:gap-2 text-[11px] sm:text-xs bg-slate-100/80 border border-slate-200/80 px-2.5 sm:px-3 py-1.5 rounded-full text-slate-700">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                <span className="font-semibold text-slate-800 truncate max-w-[120px] sm:max-w-none">
                  {session.name}
                </span>
                <span className="text-slate-400 hidden sm:inline">|</span>
                <span className="text-blue-600 font-mono hidden sm:inline">{session.hodCode}</span>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-xs text-rose-600 hover:text-rose-700 hover:bg-rose-50 h-8 px-2.5 rounded-xl border border-rose-200/60 font-semibold transition-colors flex items-center gap-1.5"
                title="Sign Out"
              >
                <LogOut className="h-3.5 w-3.5 text-rose-600" />
                <span className="hidden sm:inline">Sign Out</span>
              </Button>
            </div>
          </header>

          {/* Content Body — Full Space Fluid Edge-to-Edge Layout */}
          <main className="flex-1 overflow-y-auto p-3 sm:p-5 lg:p-6 w-full">
            <div className="w-full space-y-6 max-w-none animate-page-fade-up entrance-stagger">{children}</div>
          </main>
        </div>
      </div>
    </HODContext.Provider>
  );
}

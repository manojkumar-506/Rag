"use client";
import { AnimatedBackground } from "@/components/animated-background";

import React, { useState, useEffect } from "react";
import {
  FileText,
  Search,
  RefreshCw,
  Eye,
  Lock,
  Building,
  Globe,
  Shield,
  Sparkles,
  GitCompare,
  Plus,
  Trash2,
  CheckCircle2,
  ArrowRight,
  ExternalLink,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useHOD } from "../context";

export default function HODDocumentsPage() {
  const { activeDepartment } = useHOD();
  const [documents, setDocuments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeScope, setActiveScope] = useState<string>("ALL");
  const [search, setSearch] = useState("");

  // Document View Modal State
  const [selectedDoc, setSelectedDoc] = useState<any | null>(null);
  const [loadingDocDetail, setLoadingDocDetail] = useState(false);

  const handleViewDoc = async (docId: string) => {
    try {
      setLoadingDocDetail(true);
      const res = await fetch(`/api/documents/${docId}`);
      const data = await res.json();
      if (data.document) {
        setSelectedDoc(data.document);
      }
    } catch (err) {
      console.error("Failed to load document detail:", err);
    } finally {
      setLoadingDocDetail(false);
    }
  };

  // Syllabus Comparison State
  const [comparing, setComparing] = useState(false);
  const [compareDiff, setCompareDiff] = useState<any | null>(null);
  const [diffLoading, setDiffLoading] = useState(false);

  const fetchDocs = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/hod/documents?department=${activeDepartment}&visibility=${activeScope}`);
      const data = await res.json();
      if (data.documents) {
        setDocuments(data.documents);
      }
    } catch (err) {
      console.error("Failed to load documents:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDocs();
  }, [activeDepartment, activeScope]);

  const handleCompareSyllabus = async () => {
    setComparing(true);
    setDiffLoading(true);
    try {
      const res = await fetch(`/api/hod/compare-syllabus?courseCode=CS401&department=${activeDepartment}`);
      const data = await res.json();
      if (data.diff) {
        setCompareDiff(data.diff);
      }
    } catch (err) {
      console.error("Syllabus comparison error:", err);
    } finally {
      setDiffLoading(false);
    }
  };

  const filtered = documents.filter((d) => d.fileName.toLowerCase().includes(search.toLowerCase()));

  const scopes = [
    { id: "ALL", label: "All Scopes" },
    { id: "DEPARTMENT", label: "🏢 Department Scope" },
    { id: "FACULTY", label: "👥 Faculty Only" },
    { id: "PRIVATE", label: "🔒 Private / Confidential" },
    { id: "COLLEGE", label: "🏛️ College Scope" },
    { id: "UNIVERSITY", label: "🌐 University-Wide" },
  ];

  return (
    <AnimatedBackground>
<div className="space-y-6 font-sans">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
            <FileText className="h-6 w-6 text-blue-400" />
            Department Knowledge Repository & Syllabus Intelligence
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Multi-scope document governance, vector RAG indexing, and comparative syllabus diffs for {activeDepartment}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={handleCompareSyllabus}
            className="bg-indigo-600 hover:bg-indigo-500 text-slate-800 text-xs rounded-xl font-semibold shadow-lg shadow-indigo-600/20"
          >
            <GitCompare className="mr-1.5 h-4 w-4" />
            Compare Syllabi Diffs
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchDocs}
            disabled={loading}
            className="border-slate-200 text-slate-700 text-xs rounded-xl"
          >
            <RefreshCw className={`mr-1.5 h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* ── SYLLABUS COMPARISON ENGINE PREVIEW ─────────────────────── */}
      {comparing && (
        <Card className="bg-gradient-to-b from-indigo-500 via-purple-500 to-pink-500 to-slate-950 border-indigo-500/40 backdrop-blur-xl shadow-2xl animate-in fade-in duration-300 light-glass-card card-3d-inner anim-fade-up-1">
          <CardHeader className="pb-3 border-b border-slate-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
                  <GitCompare className="h-5 w-5" />
                </div>
                <div>
                  <CardTitle className="text-base font-bold text-slate-800 flex items-center gap-2">
                    <span>Syllabus Comparative Diff & Provenance</span>
                    <Badge className="bg-indigo-500/20 text-indigo-300 border-indigo-500/40 text-[10px]">
                      CS401 Algorithm Curriculum
                    </Badge>
                  </CardTitle>
                  <CardDescription className="text-xs text-slate-500">
                    Comparing 2025 Syllabus vs 2026 Modernized Curriculum with page-level citations
                  </CardDescription>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setComparing(false)}
                className="text-slate-500 hover:text-slate-800"
              >
                Close Diff
              </Button>
            </div>
          </CardHeader>

          {diffLoading ? (
            <CardContent className="p-8 text-center text-slate-500 space-y-2">
              <RefreshCw className="h-6 w-6 animate-spin mx-auto text-indigo-400" />
              <p className="text-xs">Computing RAG semantic vector and structural diffs...</p>
            </CardContent>
          ) : compareDiff ? (
            <CardContent className="p-5 space-y-5 text-xs">
              <div className="p-3.5 rounded-xl border border-slate-200">
                <span className="font-semibold text-indigo-300 block text-[11px] uppercase">Summary of Changes</span>
                <p className="text-slate-700 mt-1 leading-relaxed">{compareDiff.summary}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Added Modules */}
                <div className="space-y-2">
                  <h4 className="font-bold text-emerald-400 text-xs flex items-center gap-1.5">
                    <Plus className="h-4 w-4" /> Added Course Units (+2 Modules)
                  </h4>
                  {compareDiff.addedModules?.map((mod: any, idx: number) => (
                    <div key={idx} className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800 text-xs">{mod.title}</span>
                        <span className="text-[10px] text-emerald-400 font-mono">Page {mod.pageNumber}</span>
                      </div>
                      <p className="text-[11px] text-slate-700">{mod.description}</p>
                    </div>
                  ))}
                </div>

                {/* Removed Modules */}
                <div className="space-y-2">
                  <h4 className="font-bold text-rose-400 text-xs flex items-center gap-1.5">
                    <Trash2 className="h-4 w-4" /> Deprecated & Removed Modules
                  </h4>
                  {compareDiff.removedModules?.map((mod: any, idx: number) => (
                    <div key={idx} className="p-3 rounded-xl bg-rose-950/20 border border-rose-500/30 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800 text-xs">{mod.title}</span>
                        <span className="text-[10px] text-rose-400 font-mono">Page {mod.pageNumber}</span>
                      </div>
                      <p className="text-[11px] text-slate-700">{mod.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Modified Credits & Requirements */}
              <div className="p-3.5 rounded-xl border border-slate-200 space-y-2">
                <span className="font-bold text-slate-700 block text-xs">Credit & Prerequisite Adjustments</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {compareDiff.modifiedCredits?.map((cr: any, i: number) => (
                    <div key={i} className="p-2.5 rounded-lg border border-slate-200 text-[11px] space-y-1">
                      <span className="font-bold text-slate-800 block">{cr.item}</span>
                      <div className="flex items-center gap-2 font-mono">
                        <span className="text-rose-400 line-through">{cr.previous}</span>
                        <span className="text-slate-500">&rarr;</span>
                        <span className="text-emerald-400 font-bold">{cr.current}</span>
                      </div>
                      <p className="text-slate-500 text-[10px] italic">{cr.citation}</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          ) : null}
        </Card>
      )}

      {/* Scope Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl border border-slate-200">
          {scopes.map((s) => (
            <button
              key={s.id}
              onClick={() => setActiveScope(s.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeScope === s.id ? "bg-blue-600 text-slate-800 shadow" : "text-slate-500 hover:text-slate-700"
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3.5 top-2.5 h-4 w-4 text-slate-500" />
          <Input
            placeholder="Search documents by title..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 py-1.5 border-slate-200 text-slate-800 text-xs rounded-xl"
          />
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((doc) => (
          <Card key={doc.id} className="border-slate-200 backdrop-blur space-y-3 light-glass-card card-3d-inner anim-fade-up-1">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 shrink-0">
                    <FileText className="h-4 w-4" />
                  </div>
                  <CardTitle className="text-xs font-bold text-slate-800 truncate max-w-[180px]">
                    {doc.fileName}
                  </CardTitle>
                </div>
                <Badge
                  variant="outline"
                  className={`text-[9px] px-1.5 py-0 ${
                    doc.visibility === "PRIVATE"
                      ? "bg-purple-500/10 text-purple-300 border-purple-500/30"
                      : doc.visibility === "UNIVERSITY"
                      ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30"
                      : "bg-blue-500/10 text-blue-300 border-blue-500/30"
                  }`}
                >
                  {doc.visibility}
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-2 text-xs">
              <div className="flex items-center justify-between text-slate-500 p-2 rounded-lg border border-slate-200 text-[11px]">
                <span>Indexed RAG Chunks:</span>
                <span className="font-mono font-bold text-blue-400">{doc.chunksCount || 12} Chunks</span>
              </div>
              <div className="flex items-center justify-between text-slate-500 p-2 rounded-lg border border-slate-200 text-[11px]">
                <span>Knowledge Base:</span>
                <span className="text-slate-700 font-semibold truncate max-w-[120px]">{doc.knowledgeBaseName}</span>
              </div>
            </CardContent>

            <CardFooter className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
              <span>{new Date(doc.createdAt).toLocaleDateString()}</span>
              <button
                onClick={() => handleViewDoc(doc.id)}
                className="text-[11px] text-blue-400 hover:text-slate-800 flex items-center gap-1 font-semibold"
              >
                <Eye className="h-3 w-3" /> Inspect Document
              </button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* Document Inspector Modal */}
      {selectedDoc && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="border border-slate-200 rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-2 bg-blue-500/10 rounded-xl text-blue-400">
                  <FileText className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-slate-800 truncate">{selectedDoc.fileName}</h3>
                  <p className="text-[11px] text-slate-500">
                    {selectedDoc.department?.name || activeDepartment} • {selectedDoc.visibility} Scope
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedDoc(null)}
                className="text-slate-500 hover:text-slate-800 p-1 rounded-lg hover:"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 text-xs pr-1">
              <div className="grid grid-cols-3 gap-2 p-3 rounded-xl border border-slate-200 font-mono text-[11px]">
                <div>
                  <span className="text-slate-500 block text-[10px]">Total Size</span>
                  <span className="font-bold text-slate-800">{(selectedDoc.fileSize / 1024).toFixed(1)} KB</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Indexed Chunks</span>
                  <span className="font-bold text-blue-400">{selectedDoc._count?.chunks || selectedDoc.chunks?.length || 0} Chunks</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Processing Status</span>
                  <span className="font-bold text-emerald-400">{selectedDoc.processingStatus}</span>
                </div>
              </div>

              {/* Chunks */}
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">
                  Extracted Text Chunks Preview
                </span>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {selectedDoc.chunks && selectedDoc.chunks.length > 0 ? (
                    selectedDoc.chunks.map((c: any, i: number) => (
                      <div key={i} className="p-3 rounded-xl border border-slate-200/80 space-y-1">
                        <span className="text-[10px] font-mono text-indigo-400 block font-semibold">
                          Chunk {c.chunkIndex + 1} {c.pageNumber ? `(Page ${c.pageNumber})` : ""} · {c.tokenCount} Tokens
                        </span>
                        <p className="text-[11px] text-slate-700 leading-relaxed line-clamp-3">{c.content}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-slate-500 italic py-2">No chunks indexed.</p>
                  )}
                </div>
              </div>

              {selectedDoc.signedUrl && (
                <div className="pt-3 border-t border-slate-200 flex justify-end">
                  <a
                    href={selectedDoc.signedUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-slate-800 font-semibold text-xs transition-colors"
                  >
                    Open Document File ↗
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
</AnimatedBackground>
  );
}
